import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import GenderSelector from './SeletorGenero';
import NumberWheelPicker from './RoletaIdadePeso';
import HeightRuler from './RoletaAltura';
import Card from './Card';
import Button from './Button';

export default function ImcForm({
  idade,
  setIdade,
  altura,
  setAltura,
  peso,
  setPeso,
  genero,
  setGenero,
  onContinuar,
}) {
  return (
    <View style={styles.formContainer}>
      {/* GRID PRINCIPAL EM 2 COLUNAS LADO A LADO */}
      <View style={styles.mainGrid}>
        
        {/* COLUNA DA ESQUERDA: GÊNERO, IDADE E PESO */}
        <View style={styles.leftColumn}>
          
          {/* 1. SEÇÃO GÊNERO */}
          <Text style={styles.label}>Gênero</Text>
          <View style={styles.genderWrapper}>
            <GenderSelector genero={genero} setGenero={setGenero} />
          </View>

          {/* 2. SEÇÃO IDADE */}
          <Text style={styles.label}>Idade</Text>
          <NumericInput value={idade} suffix="anos" min={1} max={110} onChange={setIdade} />
          <Card variant="surface" style={styles.pickerCard}>
            <NumberWheelPicker min={1} max={110} value={idade} onChange={setIdade} />
          </Card>

          {/* 3. SEÇÃO PESO */}
          <View style={styles.labelWithUnitRow}>
            <Text style={styles.label}>Peso</Text>
            <Text style={styles.unitInline}>kg</Text>
          </View>
          <NumericInput value={peso} suffix="kg" min={20} max={220} onChange={setPeso} />
          <Card variant="surface" style={styles.pickerCard}>
            <NumberWheelPicker min={20} max={220} value={peso} onChange={setPeso} />
          </Card>

        </View>

        {/* COLUNA DA DIREITA: RÉGUA DE ALTURA */}
        <View style={styles.rightColumn}>
          <View style={styles.labelWithUnitRow}>
            <Text style={styles.label}>Altura</Text>
            <Text style={styles.unitInline}>cm</Text>
          </View>
          
          {/* Card Branco da Altura (Ocupa toda a altura da coluna) */}
          <Card variant="surface" style={styles.heightRulerCard}>
            <NumericInput value={altura} suffix="cm" min={50} max={220} onChange={setAltura} />
            <HeightRuler min={50} max={220} value={altura} onChange={setAltura} />
          </Card>
        </View>

      </View>

      {/* BOTÃO CONTINUAR */}
      <Button title="Continuar" textStyle={styles.continueText} onPress={onContinuar} style={styles.continueBtn} />
    </View>
  );
}

function NumericInput({ value, suffix, min, max, onChange }) {
  const [text, setText] = useState(String(value ?? ''));
  useEffect(() => setText(String(value ?? '')), [value]);

  useEffect(() => {
    const number = Number(text);
    if (!text || number < min || number > max) return undefined;
    const timer = setTimeout(() => onChange(number), 600);
    return () => clearTimeout(timer);
  }, [text, min, max, onChange]);

  return (
    <Card variant="input" style={styles.numericInputRow}>
      <TextInput
        style={styles.numericInput}
        value={text}
        onChangeText={(text) => {
          if (!/^\d*$/.test(text)) return;
          setText(text);
        }}
        onBlur={() => {
          const parsed = Number(text);
          const safeValue = Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : min;
          onChange(safeValue);
          setText(String(safeValue));
        }}
        onSubmitEditing={() => {
          const parsed = Number(text);
          const safeValue = Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : min;
          onChange(safeValue);
          setText(String(safeValue));
        }}
        keyboardType="number-pad"
        accessibilityLabel={`${suffix === 'anos' ? 'Idade' : suffix === 'kg' ? 'Peso' : 'Altura'} em ${suffix}`}
        selectTextOnFocus
      />
      <Text style={styles.numericUnit}>{suffix}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  formContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 20,
  },
  mainGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftColumn: {
    width: '58%', // Ocupa a maior parte da largura
  },
  rightColumn: {
    width: '38%', // Ocupa a coluna vertical da direita
  },
  label: {
    fontSize: 15,
    color: '#FF751F',
    textAlign: 'left',
    marginBottom: 6,
    fontFamily: 'Poppins_700Bold',
  },
  labelWithUnitRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  unitInline: {
    fontSize: 13,
    color: '#FF751F',
    fontFamily: 'Poppins_500Medium',
  },
  genderWrapper: {
    marginBottom: 12,
  },
  pickerCard: {
    paddingVertical: 12,
    marginBottom: 12,
    alignItems: 'center',
  },
  numericInputRow: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: 8,
    paddingHorizontal: 14, marginBottom: 8, height: 58,
  },
  numericInput: { flex: 1, paddingVertical: 0, fontSize: 16, color: '#262A3B', fontFamily: 'Poppins_500Medium', outlineStyle: 'none' },
  numericUnit: { fontSize: 12, color: '#8E8E93', fontFamily: 'Poppins_500Medium' },
  heightRulerCard: {
    flex: 1, // Faz o card da régua preencher toda a altura disponível da coluna
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueBtn: {
    alignItems: 'center',
    marginTop: 16,
    marginHorizontal: 10,
    shadowColor: '#FF751F',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 4,
  },
  continueText: { fontSize: 16 },
});
